-- =========================================================
-- Open Movements – Postgres schema (AUTO IDs + UUID access codes)
-- =========================================================

-- UUID extension (needed only for access_codes)
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE database if not EXISTS openmovement;

-- =========================================================
-- ENUM TYPES
-- =========================================================

-- teacher profile status
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'teacher_profile_status') THEN
        CREATE TYPE teacher_profile_status AS ENUM ('ACTIVE', 'INACTIVE', 'PLACED');
    END IF;
END$$;

-- school subscription status
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'subscription_status') THEN
        CREATE TYPE subscription_status AS ENUM ('TRIAL', 'ACTIVE', 'EXPIRED');
    END IF;
END$$;

-- trial access code status
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'access_code_status') THEN
        CREATE TYPE access_code_status AS ENUM ('UNUSED', 'ACTIVE', 'EXPIRED');
    END IF;
END$$;

-- full profile request status
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'request_status') THEN
        CREATE TYPE request_status AS ENUM (
            'PENDING',
            'TEACHER_CONTACTED',
            'TEACHER_ACCEPTED',
            'TEACHER_DECLINED',
            'CLOSED'
        );
    END IF;
END$$;

-- =========================================================
-- TABLE: schools
-- =========================================================

CREATE TABLE IF NOT EXISTS schools (
    id                      BIGSERIAL PRIMARY KEY,       -- AUTO INCREMENT
    -- school_code             TEXT UNIQUE NOT NULL,        -- internal code like OM-S0001

    name                    TEXT NOT NULL,
    contact_name            TEXT NOT NULL,
    email                   TEXT NOT NULL UNIQUE,
    password_hash           TEXT NOT NULL,

    country                 TEXT,
    region                  TEXT,

    subscription_status     subscription_status NOT NULL DEFAULT 'TRIAL',
    subscription_started_at TIMESTAMPTZ,
    subscription_end_at     TIMESTAMPTZ,
    verify_token            TEXT DEFAULT uuid_generate_v4()
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
    verified                BOOLEAN DEFAULT FALSE
);

CREATE INDEX IF NOT EXISTS idx_schools_subscription_status
    ON schools (subscription_status);

-- =========================================================
-- TABLE: teachers
-- =========================================================

CREATE TABLE IF NOT EXISTS teachers (
    id                          BIGSERIAL PRIMARY KEY,          -- AUTO INCREMENT
    teacher_code                TEXT UNIQUE NOT NULL,           -- OM-TXXXXX visible to schools

    full_name                   TEXT NOT NULL,
    email                       TEXT NOT NULL,
    phone                       NUMERIC,
    cv_link                     TEXT,

    current_job_title           TEXT,
    subjects                    TEXT,
    highest_qualification       TEXT,

    current_country             TEXT,
    current_region              TEXT,
    visa_status                 TEXT,
    notice_period               TEXT,

    will_move_sem1              BOOLEAN NOT NULL DEFAULT FALSE,
    will_move_sem2              BOOLEAN NOT NULL DEFAULT FALSE,
    years_experience            INTEGER,

    preferred_regions           TEXT,

    salary_min                  NUMERIC(10,2),
    salary_max                  NUMERIC(10,2),

    category                    TEXT,

    current_school_name         TEXT,

    profile_status              teacher_profile_status NOT NULL DEFAULT 'ACTIVE',
    is_visible_in_school_portal BOOLEAN NOT NULL DEFAULT TRUE,

    created_at                  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at                  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_teachers_visible
    ON teachers (is_visible_in_school_portal, profile_status);

CREATE INDEX IF NOT EXISTS idx_teachers_category
    ON teachers (category);

-- =========================================================
-- TABLE: access_codes (24h trial codes, UUID ONLY)
-- =========================================================

CREATE TABLE IF NOT EXISTS access_codes (
    id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),   -- UUID stays
    code           TEXT NOT NULL UNIQUE,                          -- e.g. ABCD1234

    school_id      BIGINT REFERENCES schools(id) ON DELETE SET NULL,

    status         access_code_status NOT NULL DEFAULT 'UNUSED',

    created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    first_used_at  TIMESTAMPTZ,
    expires_at     TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_access_codes_status ON access_codes (status);

-- =========================================================
-- TABLE: requests (Full profile requests)
-- =========================================================

CREATE TABLE IF NOT EXISTS requests (
    id              BIGSERIAL PRIMARY KEY,           -- AUTO INCREMENT
    teacher_id      BIGINT NOT NULL REFERENCES teachers(id) ON DELETE CASCADE,
    school_id       BIGINT NOT NULL REFERENCES schools(id) ON DELETE CASCADE,

    requested_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    status          request_status NOT NULL DEFAULT 'PENDING',

    school_message  TEXT,
    admin_notes     TEXT
);

CREATE INDEX IF NOT EXISTS idx_requests_teacher_id ON requests (teacher_id);
CREATE INDEX IF NOT EXISTS idx_requests_school_id ON requests (school_id);
CREATE INDEX IF NOT EXISTS idx_requests_status ON requests (status);

-- =========================================================
-- TABLE: teacher_views (analytics log)
-- =========================================================

CREATE TABLE IF NOT EXISTS teacher_views (
    id           BIGSERIAL PRIMARY KEY,
    teacher_id   BIGINT NOT NULL REFERENCES teachers(id) ON DELETE CASCADE,
    school_id    BIGINT NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
    viewed_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_teacher_views_teacher_id ON teacher_views (teacher_id);
CREATE INDEX IF NOT EXISTS idx_teacher_views_school_id ON teacher_views (school_id);
