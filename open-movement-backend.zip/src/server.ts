import express, { type Request, type Response } from "express";
import cors from "cors";
import dotenv from "dotenv";
import { pool } from "./db";
const cookieParser = require("cookie-parser");
import authRoutes from "./routes/Authentication";
import mail from "./routes/mail";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middlewares
app.use(cors());
app.use(cookieParser());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));




//All Routes with their flags
app.use('/auth' , authRoutes);


app.use('/api' , mail);


app.get("/verifyemail/:token", async (req: Request, res: Response) => {
  const { token } = req.params;

  try {
    const result = await pool.query(
      "UPDATE schools SET verified = true WHERE token = $1",
      [token]
    );

    if (result.rowCount === 0) {
      return res
        .status(400)
        .send("Invalid verification link or user not found.");
    }

    // You can redirect to frontend success page instead
    return res.send("Email verified successfully. You can now log in.");
  } catch (err) {
    console.log(err);
    return res.status(400).send("Invalid or expired verification link.");
  }
});



// Simple test route
app.get("/", (req: Request, res: Response) => {
  res.send("backend setup is ready.");
});



app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
